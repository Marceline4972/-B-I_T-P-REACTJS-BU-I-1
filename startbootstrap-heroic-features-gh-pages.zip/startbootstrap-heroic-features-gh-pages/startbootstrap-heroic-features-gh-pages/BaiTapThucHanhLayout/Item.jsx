import React from 'react';

const Item = () => {
  const cards = [1, 2, 3, 4];

  return (
    <div className="row text-center">
      {cards.map((card, index) => (
        <div className="col-lg-3 col-md-6 mb-4" key={index}>
          <div className="card h-100">
            <img src="https://via.placeholder.com/500x325" className="card-img-top" alt="placeholder" />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            </div>
            <div className="card-footer">
              <a href="#" className="btn btn-primary">Find Out More!</a>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Item;
