import React from 'react';

const Banner = () => {
  return (
    <div className="bg-light p-5 rounded-lg mb-4">
      <h1 className="display-4">A Warm Welcome!</h1>
      <p className="lead">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ipsum, dignissim ut porttitor non ridiculus elit orci, euismod adipiscing! Lorem ipsum dolor sit amet, feugiat nunc sapien sapien.
      </p>
      <a className="btn btn-primary btn-lg" href="#">Call to action!</a>
    </div>
  );
};

export default Banner;
